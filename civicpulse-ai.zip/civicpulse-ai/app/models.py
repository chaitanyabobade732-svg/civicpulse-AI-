from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app.extensions import db, login_manager

def utc_now():
    """Return current UTC datetime as timezone-naive for SQLite/Postgres compatibility."""
    return datetime.now(timezone.utc).replace(tzinfo=None)

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    mobile = db.Column(db.String(20), nullable=False)
    
    # Roles: 'citizen', 'department_official', 'supervisor', 'department_head', 'admin'
    role = db.Column(db.String(30), nullable=False, default='citizen', index=True)
    
    # Geographic location
    state = db.Column(db.String(60), nullable=True)
    district = db.Column(db.String(60), nullable=True)
    city_village = db.Column(db.String(80), nullable=True)
    
    preferred_language = db.Column(db.String(10), default='en') # 'en', 'hi', 'mr'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=utc_now)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now)
    
    # Relationships
    complaints = db.relationship('Complaint', foreign_keys='Complaint.citizen_id', backref='citizen', lazy='dynamic')
    assigned_complaints = db.relationship('Complaint', foreign_keys='Complaint.assigned_staff_id', backref='assigned_staff', lazy='dynamic')
    department_membership = db.relationship('DepartmentMembership', backref='user', uselist=False, cascade='all, delete-orphan')
    department_application = db.relationship('DepartmentApplication', foreign_keys='DepartmentApplication.user_id', backref='applicant', uselist=False)
    notifications = db.relationship('Notification', backref='recipient', lazy='dynamic', cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
        
    @property
    def is_admin(self):
        return self.role == 'admin'
        
    @property
    def is_citizen(self):
        return self.role == 'citizen'
        
    @property
    def is_department_official(self):
        return self.role == 'department_official'
        
    @property
    def is_supervisor(self):
        return self.role == 'supervisor'
        
    @property
    def is_department_head(self):
        return self.role == 'department_head'
        
    @property
    def is_any_department_staff(self):
        return self.role in ('department_official', 'supervisor', 'department_head')
        
    @property
    def unread_notifications_count(self):
        return self.notifications.filter_by(is_read=False).count()

    def __repr__(self):
        return f'<User {self.email} ({self.role})>'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class Department(db.Model):
    __tablename__ = 'departments'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(80), nullable=False, index=True)
    state = db.Column(db.String(60), nullable=False)
    district = db.Column(db.String(60), nullable=False)
    jurisdiction_type = db.Column(db.String(40), default='Municipal Corporation') # 'State', 'District', 'Municipal Corporation', 'Ward'
    description = db.Column(db.Text, nullable=True)
    
    sla_hours_day2 = db.Column(db.Integer, default=48)
    sla_hours_day4 = db.Column(db.Integer, default=96)
    
    contact_email = db.Column(db.String(120), nullable=True)
    contact_phone = db.Column(db.String(30), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=utc_now)
    
    # Relationships
    members = db.relationship('DepartmentMembership', backref='department', lazy='dynamic', cascade='all, delete-orphan')
    complaints = db.relationship('Complaint', backref='department', lazy='dynamic')

    def __repr__(self):
        return f'<Department {self.code}: {self.name}>'


class DepartmentMembership(db.Model):
    __tablename__ = 'department_memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, unique=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id', ondelete='CASCADE'), nullable=False)
    
    designation = db.Column(db.String(100), nullable=False)
    office_address = db.Column(db.String(255), nullable=True)
    employee_ref_no = db.Column(db.String(60), nullable=True)
    
    is_supervisor = db.Column(db.Boolean, default=False)
    is_head = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=utc_now)

    def __repr__(self):
        return f'<DepartmentMembership User:{self.user_id} Dept:{self.department_id} Desig:{self.designation}>'


class DepartmentApplication(db.Model):
    __tablename__ = 'department_applications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    
    department_name = db.Column(db.String(120), nullable=False)
    department_category = db.Column(db.String(80), nullable=False)
    designation = db.Column(db.String(100), nullable=False)
    employee_ref_no = db.Column(db.String(60), nullable=True)
    supervising_office = db.Column(db.String(120), nullable=True)
    
    state = db.Column(db.String(60), nullable=False)
    district = db.Column(db.String(60), nullable=False)
    jurisdiction = db.Column(db.String(100), nullable=False)
    office_address = db.Column(db.Text, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    auth_doc_path = db.Column(db.String(255), nullable=True)
    
    # Status: 'pending', 'approved', 'rejected'
    status = db.Column(db.String(20), default='pending', nullable=False, index=True)
    admin_review_notes = db.Column(db.Text, nullable=True)
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    
    created_at = db.Column(db.DateTime, default=utc_now)

    def __repr__(self):
        return f'<DepartmentApplication {self.id}: {self.department_name} ({self.status})>'


class Complaint(db.Model):
    __tablename__ = 'complaints'
    
    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.String(30), unique=True, nullable=False, index=True) # e.g. CP-2026-X7K89
    citizen_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(80), nullable=False, index=True)
    
    state = db.Column(db.String(60), nullable=False)
    district = db.Column(db.String(60), nullable=False, index=True)
    city_village = db.Column(db.String(80), nullable=False)
    address_landmark = db.Column(db.Text, nullable=False)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True, index=True)
    assigned_staff_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Status workflow:
    # 'Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned', 
    # 'Acknowledged', 'In Progress', 'On Hold', 'Resolved — Awaiting Citizen Verification',
    # 'Closed', 'Reopened', 'Rejected — With Reason'
    status = db.Column(db.String(60), default='Submitted', nullable=False, index=True)
    
    # Priority: 'Low', 'Medium', 'High', 'Urgent'
    priority = db.Column(db.String(20), default='Medium', nullable=False, index=True)
    
    # Deadlines for Escalation
    deadline_day2 = db.Column(db.DateTime, nullable=True, index=True)
    deadline_day4 = db.Column(db.DateTime, nullable=True, index=True)
    is_escalated_day2 = db.Column(db.Boolean, default=False, index=True)
    is_escalated_day4 = db.Column(db.Boolean, default=False, index=True)
    
    resolution_notes = db.Column(db.Text, nullable=True)
    resolution_proof_image = db.Column(db.String(255), nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    reopen_reason = db.Column(db.Text, nullable=True)
    reopen_count = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=utc_now, index=True)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now)
    acknowledged_at = db.Column(db.DateTime, nullable=True)
    in_progress_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    closed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    images = db.relationship('ComplaintImage', backref='complaint', lazy='dynamic', cascade='all, delete-orphan')
    status_history = db.relationship('ComplaintStatusHistory', backref='complaint', lazy='dynamic', cascade='all, delete-orphan', order_by='ComplaintStatusHistory.created_at.asc()')
    ai_analysis = db.relationship('AIAnalysisResult', backref='complaint', uselist=False, cascade='all, delete-orphan')
    escalations = db.relationship('Escalation', backref='complaint', lazy='dynamic', cascade='all, delete-orphan')
    
    # Duplicate relationships
    primary_links = db.relationship('DuplicateGroup', foreign_keys='DuplicateGroup.primary_complaint_id', backref='primary_complaint', lazy='dynamic')
    duplicate_links = db.relationship('DuplicateGroup', foreign_keys='DuplicateGroup.duplicate_complaint_id', backref='duplicate_complaint', lazy='dynamic')

    @property
    def is_resolved(self):
        return self.status in ('Resolved — Awaiting Citizen Verification', 'Closed')

    @property
    def is_overdue_day2(self):
        if not self.deadline_day2 or self.status in ('Acknowledged', 'In Progress', 'Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason'):
            return False
        d = self.deadline_day2.replace(tzinfo=None) if self.deadline_day2.tzinfo else self.deadline_day2
        return utc_now() > d

    @property
    def is_overdue_day4(self):
        if not self.deadline_day4 or self.is_resolved or self.status == 'Rejected — With Reason':
            return False
        d = self.deadline_day4.replace(tzinfo=None) if self.deadline_day4.tzinfo else self.deadline_day4
        return utc_now() > d

    def __repr__(self):
        return f'<Complaint {self.complaint_id} ({self.status})>'


class ComplaintImage(db.Model):
    __tablename__ = 'complaint_images'
    
    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False)
    image_type = db.Column(db.String(30), default='citizen_submission') # 'citizen_submission', 'resolution_proof', 'progress_evidence'
    file_path = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=True)
    caption = db.Column(db.String(150), nullable=True)
    uploaded_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)


class ComplaintStatusHistory(db.Model):
    __tablename__ = 'complaint_status_history'
    
    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False)
    previous_status = db.Column(db.String(60), nullable=True)
    new_status = db.Column(db.String(60), nullable=False)
    changed_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)
    
    # Relationship to user who made change
    changed_by = db.relationship('User', foreign_keys=[changed_by_id])


class AIAnalysisResult(db.Model):
    __tablename__ = 'ai_analysis_results'
    
    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False, unique=True)
    
    is_real_ai = db.Column(db.Boolean, default=False)
    model_name = db.Column(db.String(80), default='Deterministic Rule Engine')
    analysis_type = db.Column(db.String(40), default='Rule-based analysis') # 'External AI Provider', 'Rule-based analysis'
    
    recommended_category = db.Column(db.String(80), nullable=False)
    recommended_department_code = db.Column(db.String(50), nullable=True)
    suggested_priority = db.Column(db.String(20), nullable=False)
    confidence_score = db.Column(db.Float, default=0.85)
    
    explanation = db.Column(db.Text, nullable=False)
    safety_risks = db.Column(db.Text, nullable=True)
    potential_duplicates_summary = db.Column(db.Text, nullable=True)
    recommended_next_action = db.Column(db.Text, nullable=True)
    raw_response = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=utc_now)


class DuplicateGroup(db.Model):
    __tablename__ = 'duplicate_groups'
    
    id = db.Column(db.Integer, primary_key=True)
    primary_complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False)
    duplicate_complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False)
    
    similarity_score = db.Column(db.Float, default=0.0)
    match_type = db.Column(db.String(40), default='text_similarity') # 'text_similarity', 'geo_proximity', 'manual_link'
    marked_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)


class Escalation(db.Model):
    __tablename__ = 'escalations'
    
    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), nullable=False)
    escalation_level = db.Column(db.Integer, nullable=False) # 2 for Day 2, 4 for Day 4
    
    reason = db.Column(db.Text, nullable=False)
    recipient_role = db.Column(db.String(40), nullable=False) # 'supervisor', 'department_head'
    recipient_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Status: 'triggered', 'acknowledged', 'resolved'
    status = db.Column(db.String(30), default='triggered', nullable=False)
    notes = db.Column(db.Text, nullable=True)
    
    triggered_at = db.Column(db.DateTime, default=utc_now)
    acknowledged_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    
    recipient = db.relationship('User', foreign_keys=[recipient_user_id])


class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    notification_type = db.Column(db.String(40), default='status_change') # 'status_change', 'escalation', 'assignment', 'duplicate_warning', 'system'
    link_url = db.Column(db.String(255), nullable=True)
    is_read = db.Column(db.Boolean, default=False)
    channel = db.Column(db.String(30), default='in_app') # 'in_app', 'simulated_sms', 'simulated_email'
    
    created_at = db.Column(db.DateTime, default=utc_now)


class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    resource_type = db.Column(db.String(60), nullable=False)
    resource_id = db.Column(db.String(60), nullable=True)
    ip_address = db.Column(db.String(50), nullable=True)
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now)
    
    user = db.relationship('User', foreign_keys=[user_id])


class SystemConfiguration(db.Model):
    __tablename__ = 'system_configurations'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(80), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=False)
    description = db.Column(db.String(255), nullable=True)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now)
