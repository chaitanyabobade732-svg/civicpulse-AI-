from functools import wraps
from flask import abort, redirect, url_for, flash
from flask_login import current_user
from app.models import DepartmentApplication

def citizen_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.role != 'citizen' and not current_user.is_admin:
            flash('Access restricted to verified citizen accounts.', 'danger')
            return redirect(url_for('auth.redirect_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def department_verified_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        
        # Check if user has an unapproved department application
        app = DepartmentApplication.query.filter_by(user_id=current_user.id).first()
        if app and app.status == 'pending':
            return redirect(url_for('auth.pending_verification'))
        elif app and app.status == 'rejected':
            flash('Your departmental access application was rejected by the administrator.', 'danger')
            return redirect(url_for('auth.pending_verification'))

        if not current_user.is_any_department_staff and not current_user.is_admin:
            flash('Access restricted to authorized and verified department officials.', 'danger')
            return redirect(url_for('auth.redirect_dashboard'))
            
        return f(*args, **kwargs)
    return decorated_function

def supervisor_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.role not in ('supervisor', 'department_head', 'admin'):
            flash('Access restricted to authorized Department Supervisors and above.', 'danger')
            return redirect(url_for('auth.redirect_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def dept_head_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.role not in ('department_head', 'admin'):
            flash('Access restricted to Department Heads and Executive Authorities.', 'danger')
            return redirect(url_for('auth.redirect_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if not current_user.is_admin:
            flash('Access restricted to System Administrators.', 'danger')
            return redirect(url_for('auth.redirect_dashboard'))
        return f(*args, **kwargs)
    return decorated_function
