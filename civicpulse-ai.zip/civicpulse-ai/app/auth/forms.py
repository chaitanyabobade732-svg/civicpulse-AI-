from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, BooleanField, SelectField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError, Regexp
from app.models import User

INDIAN_STATES = [
    ('Maharashtra', 'Maharashtra'),
    ('Delhi', 'Delhi (NCT)'),
    ('Karnataka', 'Karnataka'),
    ('Tamil Nadu', 'Tamil Nadu'),
    ('Uttar Pradesh', 'Uttar Pradesh'),
    ('Gujarat', 'Gujarat'),
    ('Telangana', 'Telangana'),
    ('West Bengal', 'West Bengal'),
    ('Rajasthan', 'Rajasthan'),
    ('Madhya Pradesh', 'Madhya Pradesh'),
    ('Haryana', 'Haryana'),
    ('Punjab', 'Punjab'),
    ('Bihar', 'Bihar'),
    ('Kerala', 'Kerala'),
    ('Other State/UT', 'Other State / UT')
]

CIVIC_CATEGORIES = [
    ('Roads and Public Infrastructure', 'Roads & Public Infrastructure (PWD)'),
    ('Electricity and Streetlights', 'Electricity & Streetlights (ELEC)'),
    ('Garbage and Sanitation', 'Garbage & Sanitation (SWM)'),
    ('Water Supply', 'Water Supply & Pipelines (WSSB)'),
    ('Drainage and Sewage', 'Drainage & Sewage Network (DRAIN)'),
    ('Parks and Public Spaces', 'Parks & Horticulture (PARK)'),
    ('Traffic and Signals', 'Traffic & Signals Division (TRAF)'),
    ('Public Buildings and Government Facilities', 'Public Facilities & Estates (PBD)'),
    ('Public Transport Infrastructure', 'Public Transport Infrastructure (TID)'),
    ('Other Public Property', 'General Grievance Cell (GEN)')
]

class LoginForm(FlaskForm):
    email = StringField('Email Address', validators=[
        DataRequired(message="Email address is required."),
        Email(message="Please enter a valid email address.")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message="Password is required.")
    ])
    remember_me = BooleanField('Remember this session')
    submit = SubmitField('Secure Login')

class CitizenRegistrationForm(FlaskForm):
    full_name = StringField('Full Name', validators=[
        DataRequired(message="Full name is required."),
        Length(min=3, max=100)
    ])
    email = StringField('Email Address', validators=[
        DataRequired(message="Email address is required."),
        Email(message="Please enter a valid email address.")
    ])
    mobile = StringField('10-Digit Mobile Number', validators=[
        DataRequired(message="Mobile number is required."),
        Regexp(r'^[6-9]\d{9}$', message="Please enter a valid 10-digit Indian mobile number.")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message="Password is required."),
        Length(min=8, message="Password must be at least 8 characters long.")
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(message="Please confirm your password."),
        EqualTo('password', message="Passwords do not match.")
    ])
    state = SelectField('State / UT', choices=INDIAN_STATES, validators=[DataRequired()])
    district = StringField('District', validators=[DataRequired(), Length(min=2, max=60)])
    city_village = StringField('City / Town / Village', validators=[DataRequired(), Length(min=2, max=80)])
    preferred_language = SelectField('Preferred Language', choices=[
        ('en', 'English'),
        ('hi', 'हिन्दी (Hindi)'),
        ('mr', 'मराठी (Marathi)')
    ], default='en')
    agree_terms = BooleanField('I agree to the Terms of Service & Privacy Policy', validators=[
        DataRequired(message="You must agree to the terms to register.")
    ])
    submit = SubmitField('Register Citizen Account')

    def validate_email(self, field):
        if User.query.filter_by(email=field.data.lower().strip()).first():
            raise ValidationError('An account with this email address already exists.')

class DepartmentRegistrationForm(FlaskForm):
    full_name = StringField('Official Full Name', validators=[
        DataRequired(message="Official full name is required."),
        Length(min=3, max=100)
    ])
    email = StringField('Official Government / Dept Email', validators=[
        DataRequired(message="Official email is required."),
        Email(message="Please enter a valid official email address.")
    ])
    mobile = StringField('Official Contact Number', validators=[
        DataRequired(message="Official phone number is required."),
        Regexp(r'^[6-9]\d{9}$', message="Please enter a valid 10-digit official mobile number.")
    ])
    department_name = StringField('Department Name', validators=[
        DataRequired(message="Department name is required."),
        Length(min=3, max=120)
    ])
    department_category = SelectField('Department Grievance Domain', choices=CIVIC_CATEGORIES, validators=[DataRequired()])
    designation = StringField('Official Designation (e.g., AE, JE, Executive Engineer)', validators=[
        DataRequired(message="Designation is required."),
        Length(min=2, max=100)
    ])
    employee_ref_no = StringField('Employee ID / Official Reference Number', validators=[
        DataRequired(message="Official employee or reference ID is required."),
        Length(min=2, max=60)
    ])
    supervising_office = StringField('Supervising Office / Department Head Office', validators=[
        DataRequired(message="Supervising office is required."),
        Length(min=2, max=120)
    ])
    state = SelectField('State / UT', choices=INDIAN_STATES, validators=[DataRequired()])
    district = StringField('District Jurisdiction', validators=[DataRequired(), Length(min=2, max=60)])
    jurisdiction = StringField('Specific Jurisdiction / Municipal Ward / Zone', validators=[
        DataRequired(message="Jurisdiction zone is required."),
        Length(min=2, max=100)
    ])
    office_address = TextAreaField('Complete Office Address', validators=[
        DataRequired(message="Office address is required."),
        Length(min=10, max=500)
    ])
    reason = TextAreaField('Reason for Requesting Departmental Portal Access', validators=[
        DataRequired(message="Please provide a valid official reason."),
        Length(min=10, max=500)
    ])
    auth_document = FileField('Upload Official ID / Authorization Letter (PDF/JPG/PNG)', validators=[
        FileAllowed(['pdf', 'png', 'jpg', 'jpeg'], 'Only PDF and image files are allowed!')
    ])
    password = PasswordField('Account Password', validators=[
        DataRequired(message="Password is required."),
        Length(min=8, message="Password must be at least 8 characters long.")
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(message="Please confirm your password."),
        EqualTo('password', message="Passwords do not match.")
    ])
    official_declaration = BooleanField(
        'I hereby solemnly declare that I am a bonafide government/department official authorized to represent this agency, and acknowledge that false representation is punishable by law.',
        validators=[DataRequired(message="You must check the official declaration to apply.")]
    )
    submit = SubmitField('Submit Department Access Application')

    def validate_email(self, field):
        if User.query.filter_by(email=field.data.lower().strip()).first():
            raise ValidationError('An account with this email address already exists.')
