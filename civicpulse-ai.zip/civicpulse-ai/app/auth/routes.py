import os
import uuid
from werkzeug.utils import secure_filename
from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.models import User, DepartmentApplication, AuditLog, Notification
from app.extensions import db
from app.auth.forms import LoginForm, CitizenRegistrationForm, DepartmentRegistrationForm

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('auth.redirect_dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        user = User.query.filter_by(email=email).first()

        # Generic secure validation error
        if not user or not user.check_password(form.password.data) or not user.is_active:
            flash('Invalid email or password. Please verify your credentials.', 'danger')
            return render_template('auth/login.html', form=form)

        login_user(user, remember=form.remember_me.data)
        session['language'] = user.preferred_language or 'en'

        # Audit login
        audit = AuditLog(
            user_id=user.id,
            action='USER_LOGIN',
            resource_type='User',
            resource_id=str(user.id),
            ip_address=request.remote_addr,
            details=f"Login successful for {user.email} (Role: {user.role})"
        )
        db.session.add(audit)
        db.session.commit()

        flash(f'Welcome back, {user.full_name}!', 'success')
        next_page = request.args.get('next')
        if next_page and next_page.startswith('/'):
            return redirect(next_page)
        return redirect(url_for('auth.redirect_dashboard'))

    return render_template('auth/login.html', form=form)

@auth_bp.route('/register/citizen', methods=['GET', 'POST'])
def register_citizen():
    if current_user.is_authenticated:
        return redirect(url_for('auth.redirect_dashboard'))

    form = CitizenRegistrationForm()
    if form.validate_on_submit():
        user = User(
            email=form.email.data.strip().lower(),
            full_name=form.full_name.data.strip(),
            mobile=form.mobile.data.strip(),
            role='citizen',
            state=form.state.data,
            district=form.district.data.strip(),
            city_village=form.city_village.data.strip(),
            preferred_language=form.preferred_language.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        # In-app welcome notification
        welcome_notif = Notification(
            user_id=user.id,
            title="Welcome to CivicPulse AI",
            message="Your citizen account has been successfully created. You can now report public infrastructure problems and monitor resolution in real time.",
            notification_type='system',
            link_url="/citizen/file-complaint",
            channel='in_app'
        )
        db.session.add(welcome_notif)
        db.session.commit()

        login_user(user)
        session['language'] = user.preferred_language
        flash('Account created successfully! Welcome to CivicPulse AI.', 'success')
        return redirect(url_for('citizen.dashboard'))

    return render_template('auth/register_citizen.html', form=form)

@auth_bp.route('/register/department', methods=['GET', 'POST'])
def register_department():
    if current_user.is_authenticated:
        return redirect(url_for('auth.redirect_dashboard'))

    form = DepartmentRegistrationForm()
    if form.validate_on_submit():
        # Handle authorization document upload securely
        auth_doc_path = None
        if form.auth_document.data:
            file = form.auth_document.data
            ext = os.path.splitext(file.filename)[1].lower()
            unique_filename = f"auth_{uuid.uuid4().hex[:12]}{ext}"
            upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'verifications')
            os.makedirs(upload_dir, exist_ok=True)
            file.save(os.path.join(upload_dir, unique_filename))
            auth_doc_path = os.path.join('uploads', 'verifications', unique_filename).replace('\\', '/')

        # Create user with unverified department applicant role
        user = User(
            email=form.email.data.strip().lower(),
            full_name=form.full_name.data.strip(),
            mobile=form.mobile.data.strip(),
            role='department_applicant', # NOT verified yet!
            state=form.state.data,
            district=form.district.data.strip(),
            city_village=form.jurisdiction.data.strip(),
            preferred_language='en'
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush() # Flush to get user.id

        # Create Department Application record
        application = DepartmentApplication(
            user_id=user.id,
            department_name=form.department_name.data.strip(),
            department_category=form.department_category.data,
            designation=form.designation.data.strip(),
            employee_ref_no=form.employee_ref_no.data.strip(),
            supervising_office=form.supervising_office.data.strip(),
            state=form.state.data,
            district=form.district.data.strip(),
            jurisdiction=form.jurisdiction.data.strip(),
            office_address=form.office_address.data.strip(),
            reason=form.reason.data.strip(),
            auth_doc_path=auth_doc_path,
            status='pending'
        )
        db.session.add(application)

        # Notify System Administrators
        admins = User.query.filter_by(role='admin').all()
        for admin in admins:
            notif = Notification(
                user_id=admin.id,
                title="New Department Access Application",
                message=f"Official {user.full_name} ({application.designation}) applied for access to '{application.department_name}'. Verification required.",
                notification_type='system',
                link_url=f"/admin/applications/{application.id}",
                channel='in_app'
            )
            db.session.add(notif)

        db.session.commit()
        login_user(user)

        flash('Your departmental access application has been submitted and is currently PENDING ADMINISTRATOR VERIFICATION.', 'warning')
        return redirect(url_for('auth.pending_verification'))

    return render_template('auth/register_department.html', form=form)

@auth_bp.route('/pending-verification')
@login_required
def pending_verification():
    application = DepartmentApplication.query.filter_by(user_id=current_user.id).order_by(DepartmentApplication.created_at.desc()).first()
    return render_template('auth/pending_verification.html', application=application)

@auth_bp.route('/dashboard')
@login_required
def redirect_dashboard():
    """Redirect user to appropriate role portal."""
    if current_user.is_admin:
        return redirect(url_for('admin.dashboard'))
    elif current_user.is_department_head:
        return redirect(url_for('department_head.dashboard'))
    elif current_user.is_supervisor:
        return redirect(url_for('supervisor.dashboard'))
    elif current_user.is_department_official:
        return redirect(url_for('department.dashboard'))
    elif current_user.role == 'department_applicant':
        return redirect(url_for('auth.pending_verification'))
    else:
        return redirect(url_for('citizen.dashboard'))

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out safely.', 'info')
    return redirect(url_for('complaints.landing'))

@auth_bp.route('/change-language/<lang>')
def change_language(lang):
    if lang in ['en', 'hi', 'mr']:
        session['language'] = lang
        if current_user.is_authenticated:
            current_user.preferred_language = lang
            db.session.commit()
    return redirect(request.referrer or url_for('complaints.landing'))

@auth_bp.route('/notifications')
@login_required
def notifications():
    page = request.args.get('page', 1, type=int)
    pagination = current_user.notifications.order_by(Notification.created_at.desc()).paginate(page=page, per_page=15, error_out=False)
    return render_template('shared/notifications.html', pagination=pagination)

@auth_bp.route('/notifications/read/<int:notif_id>', methods=['POST'])
@login_required
def mark_notification_read(notif_id):
    NotificationService.mark_as_read(notif_id, current_user.id)
    return redirect(request.referrer or url_for('auth.notifications'))

@auth_bp.route('/notifications/read-all', methods=['POST'])
@login_required
def mark_all_notifications_read():
    NotificationService.mark_all_as_read(current_user.id)
    flash('All notifications marked as read.', 'info')
    return redirect(request.referrer or url_for('auth.notifications'))

