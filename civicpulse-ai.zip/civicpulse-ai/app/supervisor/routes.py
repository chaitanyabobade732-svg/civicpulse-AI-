from datetime import datetime, timezone
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.auth.decorators import supervisor_required
from app.models import Complaint, Escalation, ComplaintStatusHistory, DepartmentMembership, User, AuditLog, utc_now
from app.services.notification_service import NotificationService
from app.extensions import db

supervisor_bp = Blueprint('supervisor', __name__, url_prefix='/supervisor')

@supervisor_bp.route('/dashboard')
@login_required
@supervisor_required
def dashboard():
    """Supervisor Operational Oversight Portal."""
    now = utc_now()
    
    # Day 2 escalations query
    day2_escalations = Escalation.query.filter_by(escalation_level=2).order_by(Escalation.triggered_at.desc()).all()
    
    # Complaints approaching Day 2 deadline without action
    unresponsive_complaints = Complaint.query.filter(
        Complaint.status.in_(['Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned']),
        Complaint.is_escalated_day2 == True
    ).order_by(Complaint.deadline_day2.asc()).all()

    # Unassigned complaints
    unassigned_complaints = Complaint.query.filter_by(assigned_staff_id=None).filter(
        Complaint.status.notin_(['Closed', 'Rejected — With Reason'])
    ).all()

    return render_template(
        'supervisor/dashboard.html',
        day2_escalations=day2_escalations,
        unresponsive_complaints=unresponsive_complaints,
        unassigned_complaints=unassigned_complaints
    )

@supervisor_bp.route('/instruct/<int:complaint_id>', methods=['POST'])
@login_required
@supervisor_required
def add_instruction(complaint_id):
    """Add formal supervisory instruction to field team and record delay rationale."""
    complaint = Complaint.query.get_or_404(complaint_id)
    instructions = request.form.get('instructions', '').strip()
    reason_for_delay = request.form.get('reason_for_delay', '').strip()
    reassign_staff_id = request.form.get('reassign_staff_id', type=int)

    if not instructions:
        flash('Supervisory instructions cannot be empty.', 'danger')
        return redirect(url_for('supervisor.dashboard'))

    note_text = f"SUPERVISORY DIRECTIVE by {current_user.full_name}: {instructions}"
    if reason_for_delay:
        note_text += f" | Noted Delay Cause: {reason_for_delay}"

    if reassign_staff_id and reassign_staff_id > 0:
        assigned_user = User.query.get(reassign_staff_id)
        if assigned_user:
            complaint.assigned_staff_id = reassign_staff_id
            note_text += f" | Reassigned to: {assigned_user.full_name}"

    history = ComplaintStatusHistory(
        complaint_id=complaint.id,
        previous_status=complaint.status,
        new_status=complaint.status,
        changed_by_id=current_user.id,
        notes=note_text
    )
    db.session.add(history)

    # Acknowledge escalation record if present
    esc = Escalation.query.filter_by(complaint_id=complaint.id, escalation_level=2, status='triggered').first()
    if esc:
        esc.status = 'acknowledged'
        esc.acknowledged_at = utc_now()
        esc.notes = instructions

    # Notify assigned staff
    if complaint.assigned_staff_id:
        NotificationService.notify(
            user_id=complaint.assigned_staff_id,
            title=f"Supervisory Order: #{complaint.complaint_id}",
            message=f"Supervisor {current_user.full_name} issued directives: {instructions[:120]}",
            notification_type='escalation',
            link_url=f"/department/complaint/{complaint.id}"
        )

    db.session.commit()
    flash(f"Supervisory instructions dispatched for Grievance #{complaint.complaint_id}.", "success")
    return redirect(url_for('supervisor.dashboard'))

@supervisor_bp.route('/forward-head/<int:complaint_id>', methods=['POST'])
@login_required
@supervisor_required
def forward_to_head(complaint_id):
    """Supervisor manually forwards critical unresolved issue to Department Head."""
    complaint = Complaint.query.get_or_404(complaint_id)
    notes = request.form.get('forward_notes', '').strip() or "Forwarded manually by Zonal Supervisor due to bottleneck."

    # Trigger or elevate to Day 4 escalation
    now = utc_now()
    existing_esc = Escalation.query.filter_by(complaint_id=complaint.id, escalation_level=4).first()
    if not existing_esc:
        head_user = User.query.filter_by(role='department_head', is_active=True).first()
        esc = Escalation(
            complaint_id=complaint.id,
            escalation_level=4,
            reason=f"Manually forwarded to Department Head by Supervisor {current_user.full_name}: {notes}",
            recipient_role='department_head',
            recipient_user_id=head_user.id if head_user else None,
            status='triggered',
            triggered_at=now
        )
        db.session.add(esc)
        complaint.is_escalated_day4 = True

    history = ComplaintStatusHistory(
        complaint_id=complaint.id,
        previous_status=complaint.status,
        new_status=complaint.status,
        changed_by_id=current_user.id,
        notes=f"FORWARDED TO HEAD by Supervisor: {notes}"
    )
    db.session.add(history)
    db.session.commit()

    flash(f"Complaint #{complaint.complaint_id} forwarded directly to Department Head.", "warning")
    return redirect(url_for('supervisor.dashboard'))
