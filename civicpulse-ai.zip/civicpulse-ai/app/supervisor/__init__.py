from app.supervisor.routes import supervisor_bp

__all__ = ['supervisor_bp']
