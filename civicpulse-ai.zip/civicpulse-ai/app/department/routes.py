import os
import uuid
from datetime import datetime, timezone
from werkzeug.utils import secure_filename
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from app.auth.decorators import department_verified_required
from app.models import Complaint, Department, DepartmentMembership, ComplaintImage, ComplaintStatusHistory, User, AuditLog, utc_now
from app.services.notification_service import NotificationService
from app.services.department_router import DepartmentRouter
from app.department.forms import ManageComplaintForm, ReassignCategoryForm
from app.extensions import db

dept_bp = Blueprint('department', __name__, url_prefix='/department')

def get_user_department():
    """Retrieve verified user's assigned department."""
    if current_user.is_admin:
        # Admin can view the first department or none
        return Department.query.first()
    if not current_user.department_membership:
        return None
    return current_user.department_membership.department

@dept_bp.route('/dashboard')
@login_required
@department_verified_required
def dashboard():
    """Department Official Operational Dashboard."""
    dept = get_user_department()
    now = utc_now()

    if not dept and not current_user.is_admin:
        flash('You are not currently linked to an active department.', 'danger')
        return redirect(url_for('auth.redirect_dashboard'))

    # Base query for department's complaints
    query = Complaint.query
    if not current_user.is_admin:
        query = query.filter_by(department_id=dept.id)

    status_filter = request.args.get('status')
    priority_filter = request.args.get('priority')
    view_type = request.args.get('view') # 'urgent', 'overdue', 'new'

    if status_filter:
        query = query.filter_by(status=status_filter)
    if priority_filter:
        query = query.filter_by(priority=priority_filter)

    if view_type == 'urgent':
        query = query.filter(Complaint.priority.in_(['Urgent', 'High']))
    elif view_type == 'overdue':
        query = query.filter(
            Complaint.status.notin_(['Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason']),
            Complaint.deadline_day2 != None,
            Complaint.deadline_day2 < now
        )
    elif view_type == 'new':
        query = query.filter_by(status='Assigned')

    # Metrics
    base_dept_query = Complaint.query if current_user.is_admin else Complaint.query.filter_by(department_id=dept.id)
    total_assigned = base_dept_query.count()
    new_awaiting = base_dept_query.filter_by(status='Assigned').count()
    in_progress = base_dept_query.filter(Complaint.status.in_(['Acknowledged', 'In Progress', 'On Hold'])).count()
    urgent_count = base_dept_query.filter(Complaint.priority == 'Urgent', Complaint.status.notin_(['Closed', 'Resolved — Awaiting Citizen Verification'])).count()
    overdue_count = base_dept_query.filter(
        Complaint.status.notin_(['Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason']),
        Complaint.deadline_day2 != None,
        Complaint.deadline_day2 < now
    ).count()
    resolved_count = base_dept_query.filter(Complaint.status.in_(['Resolved — Awaiting Citizen Verification', 'Closed'])).count()

    page = request.args.get('page', 1, type=int)
    pagination = query.order_by(
        (Complaint.priority == 'Urgent').desc(),
        (Complaint.priority == 'High').desc(),
        Complaint.created_at.desc()
    ).paginate(page=page, per_page=12, error_out=False)

    return render_template(
        'department/dashboard.html',
        department=dept,
        pagination=pagination,
        total_assigned=total_assigned,
        new_awaiting=new_awaiting,
        in_progress=in_progress,
        urgent_count=urgent_count,
        overdue_count=overdue_count,
        resolved_count=resolved_count,
        status_filter=status_filter,
        priority_filter=priority_filter,
        view_type=view_type
    )

@dept_bp.route('/complaint/<int:complaint_id>', methods=['GET', 'POST'])
@login_required
@department_verified_required
def manage_complaint(complaint_id):
    """Review grievance details, change status, assign staff, upload proof."""
    dept = get_user_department()
    complaint = Complaint.query.get_or_404(complaint_id)

    # Permission check: must belong to department or admin
    if not current_user.is_admin and complaint.department_id != dept.id:
        flash('Unauthorized access: This grievance is assigned to another department.', 'danger')
        return redirect(url_for('department.dashboard'))

    manage_form = ManageComplaintForm()
    transfer_form = ReassignCategoryForm()

    # Populate staff dropdown (colleagues in same department)
    dept_members = DepartmentMembership.query.filter_by(department_id=complaint.department_id).all()
    staff_choices = [(0, '-- Unassigned / Self --')] + [(m.user_id, f"{m.user.full_name} ({m.designation})") for m in dept_members]
    manage_form.assigned_staff_id.choices = staff_choices

    if request.method == 'GET':
        manage_form.status.data = complaint.status if complaint.status in [c[0] for c in manage_form.status.choices] else 'In Progress'
        manage_form.priority.data = complaint.priority
        manage_form.assigned_staff_id.data = complaint.assigned_staff_id or 0

    if manage_form.validate_on_submit() and 'submit' in request.form:
        old_status = complaint.status
        new_status = manage_form.status.data
        new_priority = manage_form.priority.data
        assigned_id = manage_form.assigned_staff_id.data
        notes = manage_form.progress_notes.data.strip()

        # Handle resolution evidence upload
        resolution_proof_rel_path = None
        if manage_form.resolution_proof.data:
            file = manage_form.resolution_proof.data
            ext = os.path.splitext(file.filename)[1].lower()
            unique_filename = f"res_{uuid.uuid4().hex[:12]}{ext}"
            upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'resolutions')
            os.makedirs(upload_dir, exist_ok=True)
            file.save(os.path.join(upload_dir, unique_filename))
            resolution_proof_rel_path = os.path.join('uploads', 'resolutions', unique_filename).replace('\\', '/')

            proof_img = ComplaintImage(
                complaint_id=complaint.id,
                image_type='resolution_proof',
                file_path=resolution_proof_rel_path,
                original_filename=secure_filename(file.filename),
                caption=f"Resolution proof submitted by {current_user.full_name}",
                uploaded_by_id=current_user.id
            )
            db.session.add(proof_img)
            complaint.resolution_proof_image = resolution_proof_rel_path

        # Update timestamps based on workflow transition
        now = utc_now()
        if new_status == 'Acknowledged' and not complaint.acknowledged_at:
            complaint.acknowledged_at = now
        elif new_status == 'In Progress' and not complaint.in_progress_at:
            complaint.in_progress_at = now
        elif new_status == 'Resolved — Awaiting Citizen Verification':
            complaint.resolved_at = now
            complaint.resolution_notes = notes
        elif new_status == 'Rejected — With Reason':
            complaint.rejection_reason = notes

        complaint.status = new_status
        complaint.priority = new_priority
        complaint.assigned_staff_id = assigned_id if assigned_id > 0 else current_user.id

        # Record Status History
        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=old_status,
            new_status=new_status,
            changed_by_id=current_user.id,
            notes=f"[{current_user.full_name} - {dept.name}]: {notes}"
        )
        db.session.add(history)

        # Audit Log
        audit = AuditLog(
            user_id=current_user.id,
            action='COMPLAINT_STATUS_UPDATE',
            resource_type='Complaint',
            resource_id=complaint.complaint_id,
            ip_address=request.remote_addr,
            details=f"Status changed from '{old_status}' to '{new_status}'. Priority: {new_priority}."
        )
        db.session.add(audit)

        # Notify Citizen
        NotificationService.notify(
            user_id=complaint.citizen_id,
            title=f"Status Update: #{complaint.complaint_id}",
            message=f"Department updated your grievance status to '{new_status}'. Remarks: {notes[:100]}",
            notification_type='status_change',
            link_url=f"/citizen/complaint/{complaint.complaint_id}"
        )

        db.session.commit()
        flash(f'Grievance #{complaint.complaint_id} updated successfully.', 'success')
        return redirect(url_for('department.manage_complaint', complaint_id=complaint.id))

    return render_template(
        'department/manage_complaint.html',
        complaint=complaint,
        department=dept,
        manage_form=manage_form,
        transfer_form=transfer_form
    )

@dept_bp.route('/complaint/<int:complaint_id>/reassign', methods=['POST'])
@login_required
@department_verified_required
def reassign_category(complaint_id):
    """Department reassigns category and transfers complaint to another department."""
    complaint = Complaint.query.get_or_404(complaint_id)
    dept = get_user_department()

    if not current_user.is_admin and complaint.department_id != dept.id:
        abort(403)

    transfer_form = ReassignCategoryForm()
    if transfer_form.validate_on_submit():
        new_cat = transfer_form.new_category.data
        reason = transfer_form.reassignment_reason.data.strip()
        old_cat = complaint.category
        old_dept_name = dept.name if dept else 'Unknown'

        # Route to new department
        new_target_dept = DepartmentRouter.route_complaint(
            category=new_cat,
            state=complaint.state,
            district=complaint.district,
            city_village=complaint.city_village
        )

        complaint.category = new_cat
        if new_target_dept:
            complaint.department_id = new_target_dept.id
            complaint.status = 'Assigned'
            dest_msg = f"Transferred to {new_target_dept.name} ({new_target_dept.code})."
        else:
            complaint.department_id = None
            complaint.status = 'Awaiting Department Assignment'
            dest_msg = "Awaiting central administrative department reassignment."

        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=complaint.status,
            new_status=complaint.status,
            changed_by_id=current_user.id,
            notes=f"CATEGORY REASSIGNMENT: Changed from '{old_cat}' to '{new_cat}' by {old_dept_name}. Reason: {reason}. {dest_msg}"
        )
        db.session.add(history)

        # Notify citizen
        NotificationService.notify(
            user_id=complaint.citizen_id,
            title=f"Category Reassigned: #{complaint.complaint_id}",
            message=f"Department transferred your grievance from '{old_cat}' to '{new_cat}'. {dest_msg}",
            notification_type='assignment',
            link_url=f"/citizen/complaint/{complaint.complaint_id}"
        )

        db.session.commit()
        flash(f"Complaint category successfully updated to '{new_cat}'. {dest_msg}", "info")
        return redirect(url_for('department.dashboard'))

    flash("Please provide a valid justification for transferring categories.", "danger")
    return redirect(url_for('department.manage_complaint', complaint_id=complaint_id))
