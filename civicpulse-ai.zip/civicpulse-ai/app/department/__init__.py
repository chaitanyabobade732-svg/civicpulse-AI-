from app.department.routes import dept_bp

__all__ = ['dept_bp']
