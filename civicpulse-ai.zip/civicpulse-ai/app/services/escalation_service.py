from datetime import datetime, timezone
from app.models import Complaint, Escalation, ComplaintStatusHistory, Notification, DepartmentMembership, User
from app.extensions import db

def utc_now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

def to_naive(dt):
    if dt and dt.tzinfo:
        return dt.replace(tzinfo=None)
    return dt

class EscalationService:
    """Automated Day 2 / Day 4 Escalation Engine."""

    @staticmethod
    def process_all_escalations():
        """
        Evaluate all open complaints for Day 2 and Day 4 escalation conditions.
        Idempotent: Running repeatedly will never create duplicate escalation records.
        """
        now = utc_now()
        day2_count = 0
        day4_count = 0

        # Query all active complaints that are not closed or rejected
        active_complaints = Complaint.query.filter(
            Complaint.status.notin_(['Closed', 'Rejected — With Reason', 'Resolved — Awaiting Citizen Verification'])
        ).all()

        for complaint in active_complaints:
            # Check Day 2 Escalation: No action taken within 48 hours
            d2 = to_naive(complaint.deadline_day2)
            if not complaint.is_escalated_day2 and d2 and now >= d2:
                # Qualifying actions that prevent Day 2 escalation:
                # If status is still 'Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', or 'Assigned'
                unresponsive_statuses = ['Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned']
                if complaint.status in unresponsive_statuses:
                    success = EscalationService._trigger_day2_escalation(complaint, now)
                    if success:
                        day2_count += 1

            # Check Day 4 Escalation: Still unresolved within 96 hours
            d4 = to_naive(complaint.deadline_day4)
            if not complaint.is_escalated_day4 and d4 and now >= d4:

                # If complaint is still unresolved (any active status)
                success = EscalationService._trigger_day4_escalation(complaint, now)
                if success:
                    day4_count += 1

        db.session.commit()
        return {
            'status': 'success',
            'day2_escalations_triggered': day2_count,
            'day4_escalations_triggered': day4_count,
            'evaluated_at': now.isoformat()
        }

    @staticmethod
    def _trigger_day2_escalation(complaint, timestamp):
        """Idempotently trigger Level 1 (Day 2) Escalation to Department Supervisor."""
        # Double check no existing Level 2 escalation exists
        existing = Escalation.query.filter_by(
            complaint_id=complaint.id,
            escalation_level=2
        ).first()
        if existing:
            complaint.is_escalated_day2 = True
            return False

        # Find Department Supervisor
        supervisor_user = None
        if complaint.department_id:
            membership = DepartmentMembership.query.filter_by(
                department_id=complaint.department_id,
                is_supervisor=True
            ).first()
            if membership:
                supervisor_user = User.query.get(membership.user_id)

        # Fallback to general supervisor or admin if department supervisor not found
        if not supervisor_user:
            supervisor_user = User.query.filter_by(role='supervisor', is_active=True).first()

        reason = (
            f"Automated Day 2 SLA breach: No departmental action or acknowledgement recorded "
            f"within 48 hours of grievance submission ({complaint.complaint_id})."
        )

        escalation = Escalation(
            complaint_id=complaint.id,
            escalation_level=2,
            reason=reason,
            recipient_role='supervisor',
            recipient_user_id=supervisor_user.id if supervisor_user else None,
            status='triggered',
            triggered_at=timestamp
        )
        db.session.add(escalation)
        complaint.is_escalated_day2 = True

        # Status History entry
        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=complaint.status,
            new_status=complaint.status,
            changed_by_id=None,
            notes=f"SYSTEM ALERT: Day 2 Escalation triggered to Zonal Supervisor due to no official response in 48 hours.",
            created_at=timestamp
        )
        db.session.add(history)

        # Notify Supervisor
        if supervisor_user:
            notif_sup = Notification(
                user_id=supervisor_user.id,
                title=f"URGENT: Day 2 Escalation — #{complaint.complaint_id}",
                message=f"Complaint #{complaint.complaint_id} ({complaint.category}) in {complaint.district} has exceeded the 48-hour response window without action. Supervisory intervention required.",
                notification_type='escalation',
                link_url=f"/supervisor/dashboard#complaint-{complaint.id}",
                channel='in_app'
            )
            db.session.add(notif_sup)

        # Notify Citizen
        notif_cit = Notification(
            user_id=complaint.citizen_id,
            title=f"Complaint #{complaint.complaint_id} Escalated to Supervisor",
            message=f"Your grievance #{complaint.complaint_id} has not received an acknowledgement within 48 hours and has been automatically escalated to the Zonal Supervisor under CivicPulse SLA rules.",
            notification_type='escalation',
            link_url=f"/citizen/complaint/{complaint.complaint_id}",
            channel='in_app'
        )
        db.session.add(notif_cit)

        return True

    @staticmethod
    def _trigger_day4_escalation(complaint, timestamp):
        """Idempotently trigger Level 2 (Day 4) Escalation to Department Head."""
        # Double check no existing Level 4 escalation exists
        existing = Escalation.query.filter_by(
            complaint_id=complaint.id,
            escalation_level=4
        ).first()
        if existing:
            complaint.is_escalated_day4 = True
            return False

        # Find Department Head
        head_user = None
        if complaint.department_id:
            membership = DepartmentMembership.query.filter_by(
                department_id=complaint.department_id,
                is_head=True
            ).first()
            if membership:
                head_user = User.query.get(membership.user_id)

        # Fallback to general head or admin
        if not head_user:
            head_user = User.query.filter_by(role='department_head', is_active=True).first()

        reason = (
            f"Automated Day 4 SLA breach: Grievance remains unresolved after 96 hours "
            f"of registration ({complaint.complaint_id}). Transferred to Department Head for executive action."
        )

        escalation = Escalation(
            complaint_id=complaint.id,
            escalation_level=4,
            reason=reason,
            recipient_role='department_head',
            recipient_user_id=head_user.id if head_user else None,
            status='triggered',
            triggered_at=timestamp
        )
        db.session.add(escalation)
        complaint.is_escalated_day4 = True

        # Status History entry
        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=complaint.status,
            new_status=complaint.status,
            changed_by_id=None,
            notes=f"EXECUTIVE ESCALATION: Day 4 Escalation triggered directly to Department Head. Mandatory remediation required.",
            created_at=timestamp
        )
        db.session.add(history)

        # Notify Department Head
        if head_user:
            notif_head = Notification(
                user_id=head_user.id,
                title=f"EXECUTIVE ACTION: Day 4 Escalation — #{complaint.complaint_id}",
                message=f"Complaint #{complaint.complaint_id} ({complaint.title}) remains unresolved after 96 hours. Direct executive remediation is required.",
                notification_type='escalation',
                link_url=f"/department-head/dashboard#complaint-{complaint.id}",
                channel='in_app'
            )
            db.session.add(notif_head)

        # Notify Citizen
        notif_cit = Notification(
            user_id=complaint.citizen_id,
            title=f"Complaint #{complaint.complaint_id} Escalated to Department Head",
            message=f"Notice: Grievance #{complaint.complaint_id} has exceeded 96 hours without full resolution. It has been escalated to the Department Head for executive review.",
            notification_type='escalation',
            link_url=f"/citizen/complaint/{complaint.complaint_id}",
            channel='in_app'
        )
        db.session.add(notif_cit)

        return True
