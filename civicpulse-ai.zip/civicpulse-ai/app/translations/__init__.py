from app.translations.languages import translate, get_current_language, TRANSLATIONS

__all__ = ['translate', 'get_current_language', 'TRANSLATIONS']
