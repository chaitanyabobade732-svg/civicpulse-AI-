from datetime import datetime, timezone, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.auth.decorators import dept_head_required
from app.models import Complaint, Escalation, ComplaintStatusHistory, Department, User, AuditLog, utc_now
from app.services.notification_service import NotificationService
from app.extensions import db

dept_head_bp = Blueprint('department_head', __name__, url_prefix='/department-head')

@dept_head_bp.route('/dashboard')
@login_required
@dept_head_required
def dashboard():
    """Department Head Executive Oversight Dashboard."""
    now = utc_now()

    # Day 4 Escalations
    day4_escalations = Escalation.query.filter_by(escalation_level=4).order_by(Escalation.triggered_at.desc()).all()

    # Critical public hazards (Urgent priority and not closed)
    critical_hazards = Complaint.query.filter(
        Complaint.priority == 'Urgent',
        Complaint.status.notin_(['Closed', 'Resolved — Awaiting Citizen Verification', 'Rejected — With Reason'])
    ).all()

    # Long-pending unresolved complaints
    long_pending = Complaint.query.filter(
        Complaint.is_escalated_day4 == True,
        Complaint.status.notin_(['Closed', 'Resolved — Awaiting Citizen Verification', 'Rejected — With Reason'])
    ).order_by(Complaint.created_at.asc()).all()

    return render_template(
        'department_head/dashboard.html',
        day4_escalations=day4_escalations,
        critical_hazards=critical_hazards,
        long_pending=long_pending
    )

@dept_head_bp.route('/executive-action/<int:complaint_id>', methods=['POST'])
@login_required
@dept_head_required
def executive_action(complaint_id):
    """Department Head takes executive action, reassigns, or extends deadline with justification."""
    complaint = Complaint.query.get_or_404(complaint_id)
    decision = request.form.get('decision', '').strip()
    extension_hours = request.form.get('extension_hours', type=int)
    extension_reason = request.form.get('extension_reason', '').strip()
    assigned_staff_id = request.form.get('assigned_staff_id', type=int)

    if not decision:
        flash('Executive decision comments cannot be empty.', 'danger')
        return redirect(url_for('department_head.dashboard'))

    note_text = f"EXECUTIVE ORDER by Dept Head {current_user.full_name}: {decision}"

    # Handle formal deadline extension if granted
    now = utc_now()
    if extension_hours and extension_hours > 0:
        if not extension_reason:
            flash('A mandatory justification is legally required to extend public grievance deadlines.', 'danger')
            return redirect(url_for('department_head.dashboard'))
        
        old_deadline = complaint.deadline_day4
        complaint.deadline_day4 = now + timedelta(hours=extension_hours)
        note_text += f" | APPROVED DEADLINE EXTENSION: +{extension_hours} hrs. Reason: {extension_reason} (Prev deadline: {old_deadline.strftime('%d %b %Y') if old_deadline else 'N/A'})"

    if assigned_staff_id and assigned_staff_id > 0:
        staff_user = User.query.get(assigned_staff_id)
        if staff_user:
            complaint.assigned_staff_id = staff_user.id
            note_text += f" | Assigned Direct Remediation to: {staff_user.full_name}"

    history = ComplaintStatusHistory(
        complaint_id=complaint.id,
        previous_status=complaint.status,
        new_status=complaint.status,
        changed_by_id=current_user.id,
        notes=note_text
    )
    db.session.add(history)

    # Acknowledge escalation record
    esc = Escalation.query.filter_by(complaint_id=complaint.id, escalation_level=4, status='triggered').first()
    if esc:
        esc.status = 'acknowledged'
        esc.acknowledged_at = now
        esc.notes = decision

    # Notify Citizen of Head review and transparent deadline update
    NotificationService.notify(
        user_id=complaint.citizen_id,
        title=f"Executive Review: #{complaint.complaint_id}",
        message=f"Department Head reviewed your grievance. Order: {decision[:100]}" + (f" (Approved Revised SLA: +{extension_hours}h)" if extension_hours else ""),
        notification_type='escalation',
        link_url=f"/citizen/complaint/{complaint.complaint_id}"
    )

    db.session.commit()
    flash(f"Executive order successfully executed for Grievance #{complaint.complaint_id}.", "success")
    return redirect(url_for('department_head.dashboard'))
