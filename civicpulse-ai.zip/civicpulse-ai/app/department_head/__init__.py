from app.department_head.routes import dept_head_bp

__all__ = ['dept_head_bp']
